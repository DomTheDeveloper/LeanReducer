# Four results inside the compact GRH proof

These 347 project modules prove the existence of the auxiliary data, a determinant height bound, the second-moment estimates for the filling argument, and the one-sided analytic criterion. The package covers 31,714 nonblank code lines and 49,230 physical Lean lines, plus the pinned Mathlib dependency. The complete RH and Dirichlet GRH proof also requires the remaining arithmetic and covolume arguments.

The four roots are New.Data.DataExist, New.Heights.OneDeterminant, New.Filling.Moments, New.Endgame.OneSidedCriterion. The source is unchanged from lsernau/grh-lean at 72fead102f663d5c7a407964a13dc0cf9d977207. The Lake configuration selects the included libraries. Every included source file matched Andrew Sutherland's published SHA-256 record, and every module has a successful entry in his kernel replay of the original project. KERNEL-REPLAY.txt contains those entries. A fresh local source build is a separate check.

Run `sha256sum -c SOURCE.sha256`, `lake exe cache get`, then `lake build`. See LICENSE, NOTICE, ATTRIBUTION.md and REFERENCES.md for the upstream work.
